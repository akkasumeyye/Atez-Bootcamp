Ödevler

1 - Bir text dosyasının içine istediğimiz cümleyi yazacak bir fonksiyon yazılması (New line olarak yazılması gerekmekte)
2 - Bir text dosyasının belirtilen lokasyondan istenilen lokasyana bir kopyasının oluşturulması için fonksiyon yazılması
3 - Belirtilen lokasyandaki dosya veya dosyaları zip dosyası haline getirecek bir fonksiyon yazılması
4 - HTTP server yaratarak filesystem de pages klasoru altındaki farklı uzantılarda ki sayfaları serve edecek bir server yazılması (js, html, css). (Ipucu olarak regular expression)
5- TODO cli uygulamasının diğer örneklerinin tamamlanması (Update, Check task vs)
6 - TODO cli uygulamasın checkbox özelliği ekleyerek marked duruma geldiği zaman onu işaretlemiş olacak çalışma (npm üzerinden yeni paket yükleyerek deneyebilirsiniz)
7  - TODO cli commonjs den module olarak çevirilmesi
8 - (Opsiyonel ama artı puan yazacak) File Manager cli uygulaması yazılması


8 numaralı task özellikleri;
1- Bulunduğu lokasyanda ls komutu ile tablo halinde lokasyandaki dosyaları tablo halinde gösterebilmek
2- cd komutu ile istenilen lokasyona gönderilme
3- upFolder komutu ile bir üst foldera gitme sağlanması
4- os komutlarının desteklenmesi (Örnek olarak os --username dediğim de kullanıcı adımı alabilmeliyim)
5 - Kopyalama işlemi ve rename işlemi yapabilmeliyim

Yaratıcılık konusunda denilenlerin üstüne ekleyecekleriniz değerlendirmede katkı sağlayacak arkadaşlar.

Dipnot: Bu yazılanların hepsini Typescript ile entegre ederek yazılması gerekmektedir.

Araştırma Konuları

1- RegEx
2 - HTTP Status Codes
3 - Nodejs Events
4 - Semantic Versioning
5 - Git Commit Conventions